# Team 1 - Final Project.
 > Jeremy DeHay | Jenney Chang

 > Champlain College SDEV-450


This program is designed to generate and store passwords and other account information.

To be able to access the database files, run a MySQL Workbench server with the following parameters:

Host: 127.0.0.1

Port: 3306

User: root

Password: root

After that, simply create an account and sign into the program to store information about your accounts including
 - Passwords
 - Account Names
 - Created and Modified Timestamps
 - Account notes


